package org.appinventor;
import com.google.appinventor.components.runtime.HandlesEventDispatching;
import com.google.appinventor.components.runtime.EventDispatcher;
import com.google.appinventor.components.runtime.Form;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.VerticalArrangement;
import com.google.appinventor.components.runtime.Label;
import com.google.appinventor.components.runtime.TextBox;
import com.google.appinventor.components.runtime.Button;
import com.google.appinventor.components.runtime.Image;
import com.google.appinventor.components.runtime.VerticalScrollArrangement;
import com.google.appinventor.components.runtime.HorizontalArrangement;
import com.google.appinventor.components.runtime.FirebaseDB;
import com.google.appinventor.components.runtime.Clock;
import com.google.appinventor.components.runtime.Notifier;
class Screen1 extends Form implements HandlesEventDispatching {
  private VerticalArrangement vertical_signup;
  private Label label2;
  private TextBox textbox_signup_username;
  private TextBox textbox_signup_password;
  private Button button_request_signup;
  private Button button_cancel_signup;
  private VerticalArrangement vertical_login;
  private Image image;
  private Label label1;
  private TextBox textbox_login_username;
  private TextBox textbox_login_password;
  private Button button_login;
  private Button button_signup;
  private VerticalArrangement vertical_chat;
  private Button button_chat_exit;
  private VerticalScrollArrangement vertical_scroll;
  private Label label_content_chat;
  private HorizontalArrangement horizon_layout;
  private TextBox textbox_message;
  private Button button_send;
  private FirebaseDB firebase_DB1;
  private Clock clock;
  private FirebaseDB firebase_DB2;
  private Notifier alarm;
  protected void $define() {
    this.AppName("chat");
    this.Title("Screen1");
    vertical_signup = new VerticalArrangement(this);
    vertical_signup.AlignHorizontal(3);
    vertical_signup.AlignVertical(2);
    vertical_signup.Height(LENGTH_FILL_PARENT);
    vertical_signup.Width(LENGTH_FILL_PARENT);
    vertical_signup.Visible(false);
    label2 = new Label(vertical_signup);
    label2.FontSize(15);
    label2.Text("ONSIMI TALK 회원가입 하기");
    label2.Visible(false);
    textbox_signup_username = new TextBox(vertical_signup);
    textbox_signup_username.Hint("사용자명을 입력하세요.");
    textbox_signup_password = new TextBox(vertical_signup);
    textbox_signup_password.Hint("비밀번호를 입력하세요.");
    button_request_signup = new Button(vertical_signup);
    button_request_signup.Width(-1050);
    button_request_signup.Text("가입 신청하기");
    button_cancel_signup = new Button(vertical_signup);
    button_cancel_signup.Width(-1050);
    button_cancel_signup.Text("가입 취소하기");
    vertical_login = new VerticalArrangement(this);
    vertical_login.AlignHorizontal(3);
    vertical_login.AlignVertical(2);
    vertical_login.Height(LENGTH_FILL_PARENT);
    vertical_login.Width(LENGTH_FILL_PARENT);
    image = new Image(vertical_login);
    image.Height(100);
    image.Width(120);
    image.Picture("ongsim.jpg");
    label1 = new Label(vertical_login);
    label1.FontBold(true);
    label1.FontSize(25);
    label1.Text("ONGSIMI TALK");
    textbox_login_username = new TextBox(vertical_login);
    textbox_login_username.Hint("사용자명");
    textbox_login_password = new TextBox(vertical_login);
    textbox_login_password.Hint("비밀번호");
    button_login = new Button(vertical_login);
    button_login.Width(-1050);
    button_login.Text("로그인");
    button_signup = new Button(vertical_login);
    button_signup.Width(-1050);
    button_signup.Text("회원가입");
    vertical_chat = new VerticalArrangement(this);
    vertical_chat.Height(LENGTH_FILL_PARENT);
    vertical_chat.Width(LENGTH_FILL_PARENT);
    vertical_chat.Visible(false);
    button_chat_exit = new Button(vertical_chat);
    button_chat_exit.Text("채팅방 나가기");
    vertical_scroll = new VerticalScrollArrangement(vertical_chat);
    vertical_scroll.Height(LENGTH_FILL_PARENT);
    vertical_scroll.Width(LENGTH_FILL_PARENT);
    label_content_chat = new Label(vertical_scroll);
    label_content_chat.Text("채팅방에 입장하셨습니다.");
    horizon_layout = new HorizontalArrangement(vertical_chat);
    horizon_layout.Width(LENGTH_FILL_PARENT);
    textbox_message = new TextBox(horizon_layout);
    textbox_message.Width(LENGTH_FILL_PARENT);
    textbox_message.Hint("메세지를 입력하세요.");
    button_send = new Button(horizon_layout);
    button_send.Text("전송");
    firebase_DB1 = new FirebaseDB(this);
    firebase_DB1.FirebaseToken(eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkIjp7InVpZCI6IjBkYjEwNGE0LTcyNWMtNDFjNi1hZDhiLTkwZGM5MGZhODA2NCIsInByb2plY3QiOiJjaGF0X2FwcCIsImRldmVsb3BlciI6ImJubTA4OTZAZ21haWw6Y29tIn0sInYiOjAsImV4cCI6MTY3NDI2MzAyODMsImlhdCI6MTYyNjg2Mzg4M30.i4AfrqPaLqU7cUBKYZSmdWDO2k3ReqeV9DiuT6bbakY);
    firebase_DB1.FirebaseURL(https://hackerton-chat-default-rtdb.firebaseio.com/);
    firebase_DB1.ProjectBucket(chat);
    clock = new Clock(this);
    firebase_DB2 = new FirebaseDB(this);
    firebase_DB2.FirebaseToken(eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJkIjp7InVpZCI6IjI1YjNiZGFmLTI2NzYtNDRlNC1iMDA3LWQ0YWNkYWQxMTcwOSIsInByb2plY3QiOiJjaGF0X2FwcCIsImRldmVsb3BlciI6ImJubTA4OTZAZ21haWw6Y29tIn0sInYiOjAsImV4cCI6MTY3NDI2MzAyODMsImlhdCI6MTYyNjg2Mzg4M30.jumblNLrdL3J_F57bsZRoKaKZUP8IpgKYgU1FPf5kVo);
    firebase_DB2.FirebaseURL(https://hackerton-chat-default-rtdb.firebaseio.com/);
    firebase_DB2.ProjectBucket(user);
    alarm = new Notifier(this);
    EventDispatcher.registerEventForDelegation(this, "ClickEvent", "Click" );
    EventDispatcher.registerEventForDelegation(this, "TimerEvent", "Timer" );
    EventDispatcher.registerEventForDelegation(this, "GotValueEvent", "GotValue" );
    EventDispatcher.registerEventForDelegation(this, "InitializeEvent", "Initialize" );
  }
  public boolean dispatchEvent(Component component, String componentName, String eventName, Object[] params){
    if( component.equals(button_send) && eventName.equals("Click") ){
      button_sendClick();
      return true;
    }
    if( component.equals(clock) && eventName.equals("Timer") ){
      clockTimer();
      return true;
    }
    if( component.equals(firebase_DB1) && eventName.equals("GotValue") ){
      firebase_DB1GotValue((String)params[0], (Object)params[1]);
      return true;
    }
    if( component.equals(this) && eventName.equals("Initialize") ){
      thisInitialize();
      return true;
    }
    if( component.equals(button_signup) && eventName.equals("Click") ){
      button_signupClick();
      return true;
    }
    if( component.equals(button_chat_exit) && eventName.equals("Click") ){
      button_chat_exitClick();
      return true;
    }
    if( component.equals(button_cancel_signup) && eventName.equals("Click") ){
      button_cancel_signupClick();
      return true;
    }
    if( component.equals(button_request_signup) && eventName.equals("Click") ){
      button_request_signupClick();
      return true;
    }
    if( component.equals(button_login) && eventName.equals("Click") ){
      button_loginClick();
      return true;
    }
    if( component.equals(firebase_DB2) && eventName.equals("GotValue") ){
      firebase_DB2GotValue((String)params[0], (Object)params[1]);
      return true;
    }
    return false;
  }
  public void button_sendClick(){
  }
  public void clockTimer(){
  }
  public void firebase_DB1GotValue(String tag, Object value){
    label_content_chat.Text(value);
  }
  public void thisInitialize(){
    clear_all_pages();
    vertical_login.Visible(true);
  }
  public void button_signupClick(){
    clear_all_pages();
    vertical_signup.Visible(true);
  }
  public void button_chat_exitClick(){
    clear_all_pages();
    vertical_login.Visible(true);
  }
  public void button_cancel_signupClick(){
    clear_all_pages();
    vertical_login.Visible(true);
  }
  public void button_request_signupClick(){
  }
  public void button_loginClick(){
    firebase_DB2.GetValue(textbox_login_username.Text(), "no username");
  }
  public void firebase_DB2GotValue(String tag, Object value){
    if(value.equals("no username")){
    }
    else {
      if(value.equals(textbox_login_password.Text())){
      }
      else {
      }
    }
  }
  public void clear_all_pages(){
    vertical_login.Visible(false);
    vertical_signup.Visible(false);
    vertical_chat.Visible(false);
  }
}